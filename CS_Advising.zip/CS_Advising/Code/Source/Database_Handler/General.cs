﻿using System;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
using System.Security;

namespace Database_Handler
{
    /// <summary>
    /// Exception that is thrown when the recursion depth exceeds a specified limit.
    /// </summary>
    public class RecursionDepthException : Exception
    {
        /// <summary>Constructs a new exception object.</summary>
        /// <param name="msg">The message.</param>
        public RecursionDepthException(string msg) : base(msg) { }
    } // end Class RecursionDepthException

    /// <summary>Exception class for an error that occurs while retrieving an object from a database.</summary>
    public class RetrieveError : Exception
    {
        /// <summary>Type of object that was supposed to be retrieved.</summary>
        public char Type { get; }

    /// <summary>Constructor for this exception.</summary>
    /// <param name="msg">The message.</param>
    /// <param name="type">The type of object that was supposed to be retrieved.</param>
        public RetrieveError(string msg, char type) : base(msg) => Type = type;
    }; // end Class RetrieveError
} // end namespace Database_Handler