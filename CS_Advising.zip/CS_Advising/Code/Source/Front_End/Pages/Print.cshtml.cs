﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace CwuAdvising.Pages
{
    /// <summary>Model for printing page</summary>
    public class PrintModel : PageModel
    {
        
    }
}